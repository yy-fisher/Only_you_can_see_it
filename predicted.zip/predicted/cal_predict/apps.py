from django.apps import AppConfig


class CalPredictConfig(AppConfig):
    name = 'cal_predict'
