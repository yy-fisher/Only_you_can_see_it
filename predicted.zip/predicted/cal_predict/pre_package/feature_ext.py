import numpy as np
from .train_need import read_feature_data, Model_Evaluate
import os

def read_fasta_file(file_name):
    with open(file_name, encoding='utf-8') as Data_file:
        file_str = ''
        for i, line in enumerate(Data_file):
            file_str += line

    all_sequence = file_str.split('\n')
    len_sequence = len(all_sequence)
    sequence_dict = {}
    for i in range(0, len_sequence-1, 2):
        if all_sequence[i][:2] == ">P":
            seq_label = 1
        else:
            seq_label = 0
        sequence_dict[all_sequence[i]] = [all_sequence[i+1], seq_label]

    return sequence_dict


native_acids = 'AUCG'
Free_energy = [-3.260,-2.350,-3.420,-2.240,-2.080,-0.930,-2.240,-1.100,-2.360,-2.110,-3.260,-2.080,-2.110,-1.330,-2.350,-0.930]
Hydrophilicity = [0.170,0.100,0.260,0.270,0.080,0.040,0.140,0.140,0.350,0.210,0.490,0.520,0.340,0.210,0.480,0.440]
Stacking_energy = [-11.100,-14.200,-16.900,-13.800,-14.000,-13.700,-13.800,-15.400,-15.600,-14.400,-11.100,-14.000,-14.400,-16.000,-14.200,-13.700]
Dinucleotide = ['GG','GA','GC','GU','AG','AA','AC','AU','CG','CA','CC','CU','UG','UA','UC','UU']


def tr_dic(keys, values):
    return dict(zip(keys, values))


# 计算标准差
def cal_standard(property_list):
    property_np = np.array(property_list)
    property_np_mean = np.mean(property_np)
    # property_np_sd = np.std(property_np)
    property_np_sd = np.sqrt(np.sum(pow(np.array(property_np)-property_np_mean,2))/(len(property_list)-1))
    return (property_np-property_np_mean)/property_np_sd


# 计算相关性
def calc_correlation(Ri, Rj, pro_dic):
    correlation = 0
    for pro_dic_sub in pro_dic:
        correlation += pow(float(pro_dic_sub[Ri]) - float(pro_dic_sub[Rj]), 2)

    return correlation/len(pro_dic)


# 计算theta
def theta(seq, j, pro_dic):
    L = len(seq)
    sum_corre = 0
    for i in range(L-j-1):
        sum_corre += calc_correlation(seq[i:i+1+1], seq[i+j:i+1+j+1], pro_dic)
    return sum_corre/(L-j-1)


# 计算频率 
def cla_frequency(tol_str, tar_str):
    """
    :param tol_str: mother string.
    :param tar_str: substring.
    """
    i, j, tar_count = 0, 0, 0
    len_tol_str = len(tol_str)
    len_tar_str = len(tar_str)

    while i < len_tol_str and j < len_tar_str:
        if tol_str[i] == tar_str[j]:
            i += 1
            j += 1
            if j >= len_tar_str:
                tar_count += 1
                i = i - j + 1
                j = 0
        else:
            i = i - j + 1
            j = 0

    return tar_count


# 计算pseDNC
def calc_pseDNC(seq, w, lambd):
    seq = seq[0].upper()
    L = len(seq)
    DNC = []

    # 计算标准差
    Free_energy_tr = cal_standard(Free_energy)
    Hydrophilicity_tr = cal_standard(Hydrophilicity)
    Stacking_energy_tr = cal_standard(Stacking_energy)

    # 转化为字典
    Free_energy_dic = tr_dic(Dinucleotide, Free_energy_tr)
    Hydrophilicity_dic = tr_dic(Dinucleotide, Hydrophilicity_tr)
    Stacking_energy_dic = tr_dic(Dinucleotide, Stacking_energy_tr)

    pro_dic = [Free_energy_dic, Hydrophilicity_dic, Stacking_energy_dic]
    
    # 计算DNC
    frequnce = []
    for sub_Dinucl in Dinucleotide:
        frequnce.append(cla_frequency(seq, sub_Dinucl))

    f = np.array(frequnce)/(len(seq)-1)
    sum_frequnce = sum(f)

    theta_list = []
    for i in range(1, lambd+1):
        theta_list.append(theta(seq, i, pro_dic))

    DNC_tmp = []
    # 1<u<16
    for i in f:
        d_u = i/(1 + w*np.sum(theta_list))
        DNC_tmp.append(d_u)

    DNC_tmp = tr_dic(Dinucleotide, DNC_tmp)
    for nucle in sorted(DNC_tmp):
        DNC.append(DNC_tmp[nucle])
        
    # 17<u<16+lambd
    for theta_sub in theta_list:
        d_u = (w*theta_sub)/(1 + w*np.sum(theta_list))
        DNC.append(d_u)

    return DNC


def get_PseDNC(seqs, w, lambd):
    vectors = []
    for name, seq in seqs.items():
        pseDNC = calc_pseDNC(seq, w, lambd)
        vectors.append(pseDNC)

    return vectors


# K_mer
def make_kmer_list(k, alphabet):
    """
    Generate kmer list.
    """
    if k < 0:
        print("Error, k must be an inter and larger than 0.")

    kmers = []
    for i in range(1, k + 1):
        if len(kmers) == 0:
            kmers = list(alphabet)
        else:
            new_kmers = []
            for kmer in kmers:
                for c in alphabet:
                    new_kmers.append(kmer + c)
            kmers = new_kmers

    return kmers


def frequency(tol_str, tar_str):
    """Generate the frequency of tar_str in tol_str.

    :param tol_str: mother string.
    :param tar_str: substring.
    """
    i, j, tar_count = 0, 0, 0
    len_tol_str = len(tol_str)
    len_tar_str = len(tar_str)

    while i < len_tol_str and j < len_tar_str:
        if tol_str[i] == tar_str[j]:
            i += 1
            j += 1
            if j >= len_tar_str:
                tar_count += 1
                i = i - j + 1
                j = 0
        else:
            i = i - j + 1
            j = 0

    return tar_count


def make_kmer_vector(seq, k):
    """Generate kmer vector."""
    alphabet = 'ACGU'

    kmer_list = make_kmer_list(k, alphabet)

    count_sum = 0

    kmer_count = {}
    for kmer in kmer_list:
        temp_count = frequency(seq, kmer)
        if kmer not in kmer_count:
            kmer_count[kmer] = 0
        kmer_count[kmer] += temp_count

        count_sum += temp_count

    count_vec = [kmer_count[kmer] for kmer in kmer_list]
    count_vec = [round(float(e)/count_sum, 8) for e in count_vec]

    return count_vec

def get_Kmer(seqs):
    vectors = []

    for name, seq in seqs.items():
        k_mer1 = make_kmer_vector(seq[0], 1)
        k_mer2 = make_kmer_vector(seq[0], 2)
        kmer = np.hstack([k_mer2, k_mer1])
        vectors.append(kmer)

    return vectors



# NCP
nucleotides = {
    'A' : [1,1,1],
    'C' : [0,1,0],
    'G' : [1,0,0],
    'U' : [0,0,1]
}

def NCP(sequence):
    vector = []
    for i, nucleo in enumerate(sequence):
        vector += nucleotides[nucleo]
    return vector


def get_NCP(seqs):
    vectors = []
    for name, seq in seqs.items():
        ncp = NCP(seq[0])
        vectors.append(ncp)
    return vectors



# one-hot

def one_hot(sequence):
    nucleotides = {
    'A' : [1,0,0,0],
    'C' : [0,1,0,0],
    'G' : [0,0,1,0],
    'U' : [0,0,0,1]
    }

    vector = []
    for i, nucleo in enumerate(sequence):
        vector += nucleotides[nucleo]
    return vector

def TWO_HOT(sequence):

    nucleotides = {
    'AA' : [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
    'AC' : [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0],
    'AG' : [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0],
    'AU' : [0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0],
    'CA' : [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0],
    'CC' : [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0],
    'CG' : [0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
    'CU' : [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],
    'GA' : [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
    'GC' : [0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0],
    'GG' : [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0],
    'GU' : [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
    'UA' : [0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0],
    'UC' : [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0],
    'UG' : [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
    'UU' : [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    }

    vector = []
    for i in range(len(sequence)-1):
        vector += nucleotides[sequence[i:i+2]]
    return vector

def get_one_hot(seqs):
    vectors = []
    for name, seq in seqs.items():
        O1 = one_hot(seq[0])
        O2 = TWO_HOT(seq[0])
        OO = np.hstack([O1,O2])
        vectors.append(OO)
    return vectors


# ND
def calculate_density(subsquen, keyword, n):
    len_sub = len(subsquen)
    key_count = 0
    for i in range(len(subsquen)-n+1):
        nucleo = subsquen[i:i+n]
        if nucleo == keyword:
            key_count += 1

    return round(key_count / (len_sub-n+1), 8)


def DD(sequence, n):
    vector = []
    for i in range(len(sequence)-n+1):
        subsquen = sequence[:i+n]
        nucleo = sequence[i:i+n]
        density = calculate_density(subsquen, nucleo, n)
        vector += [density]
    return vector


def get_TD(seqs):
    vectors = []
    for name, seq in seqs.items():
        D1 = DD(seq[0], 1)
        D2 = DD(seq[0], 2)
        TD = np.hstack([D1,D2])
        vectors.append(TD)
    return vectors



# PSTNP
def CalculateMatrix(data, order, k):
    matrix = np.zeros((len(data) - k+1, 4**k))
    for i in range(len(data[0]) - k+1): # position
        for j in range(len(data)):
            matrix[i][order[data[j][i:i+k]]] += 1
    return matrix


def PSTNP(train_seq, test_seq, train_label, k):

    test_encodings = []
    positive = []
    negative = []

    for i, seq in enumerate(train_seq):
        sequence = seq[0]
        if train_label[i] == 1:
            positive.append(sequence)
        else:
            negative.append(sequence)

    nucleotides = ['A', 'C', 'G', 'U']
    kmers = []
    for i in range(1, k + 1):
        if len(kmers) == 0:
            kmers = list(nucleotides)
        else:
            new_kmers = []
            for kmer in kmers:
                for c in nucleotides:
                    new_kmers.append(kmer + c)
            kmers = new_kmers

    order = {}
    for i in range(len(kmers)):
        order[kmers[i]] = i

    matrix_po = CalculateMatrix(positive, order, k)
    matrix_ne = CalculateMatrix(negative, order, k)

    positive_number = len(positive)
    negative_number = len(negative)

    # =====================================
    for seq in test_seq:

        sequence = seq[0]
        code = []
        for j in range(len(sequence) - k+1):
            p_num, n_num = positive_number, negative_number
            po_number = matrix_po[j][order[sequence[j: j+k]]]
            ne_number = matrix_ne[j][order[sequence[j: j+k]]]
            code.append(po_number/p_num - ne_number/n_num)

        test_encodings.append(code)
    return np.array(test_encodings)


def get_pstnp(name, query_seq, k):
    file_train_csv = 'E:/predicted/cal_predict/pre_package/fasta/{0}.csv'.format(name)
    X_train_PSTNP, Y_train_PSTNP = read_feature_data(file_train_csv)
    return_seq = PSTNP(X_train_PSTNP, query_seq, Y_train_PSTNP, k)

    return return_seq


def pstnp(seqs, name):
    seq = np.array(seqs[0]).reshape(len(seqs),1)
    pstn1 = get_pstnp(name, seq, 1)
    pstn2 = get_pstnp(name, seq, 2)

    pstn = np.hstack([pstn1, pstn2])
    return pstn


# def get_sequecne(seq, w, lambd):
#     psednc = calc_pseDNC(seq, w, lambd)
#     k_mer1 = make_kmer_vector(seq, 1)
#     k_mer2 = make_kmer_vector(seq, 2)
#     ncp = NCP(seq)
#     one = one_hot(seq)
#     two = TWO_HOT(seq)
#     nd = ND(seq)
#     dd = DD(seq)

#     fusion_vec = np.hstack((k_mer2, k_mer1, ncp, nd, dd, one, two, psednc))
#     return fusion_vec
