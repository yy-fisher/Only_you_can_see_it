from rest_framework import serializers

__author__ = 'LinXi'
# -*- coding: utf-8 -*-


class SequenceSerializer(serializers.Serializer):
    Species = serializers.CharField(required=True)
    Sequence = serializers.CharField()
    UploadPath = serializers.CharField()


class UploadSerializer(serializers.Serializer):
    UploadFile = serializers.FileField()
