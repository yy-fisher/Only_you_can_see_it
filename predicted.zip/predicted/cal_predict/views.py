from rest_framework import mixins
from rest_framework import viewsets
from .serializers import SequenceSerializer, UploadSerializer
from rest_framework.response import Response
from rest_framework import status
from .pre_package.vote import predicted
from django.http import FileResponse
from urllib import parse
import os
import datetime
from .pre_package.train_need import read_fasta_file
import random

# Create your views here.
class CalculateView(mixins.CreateModelMixin, viewsets.GenericViewSet):
    serializer_class = SequenceSerializer

    def create(self, request, *args, **kwargs):
        GetSequence_dict = {}
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            GetSpecies = serializer.validated_data["Species"]
            GetSequence = serializer.validated_data["Sequence"]
            GetUpload = serializer.validated_data["UploadPath"]
            headers = self.get_success_headers(serializer.data)
            species = ''
            if GetSpecies == 'S_628':
                species = 'S.cerevisiae'
            elif GetSpecies == 'H_990':
                species = 'H.sapiens'
            elif GetSpecies == 'M_944':
                species = 'M.musculus'

            if 'media' in GetUpload:
                GetSequence_dict = read_fasta_file(GetUpload)
                os.remove(GetUpload)
            else:
                GetSequence = GetSequence.split('\n')
                for i in range(0, len(GetSequence), 2):
                    if '>' == GetSequence[i][0]:
                        GetSequence_dict[GetSequence[i][1:]] = [GetSequence[i+1], None]
                    else:
                        break
            try:
                GetSequence_seq = GetSequence_dict.copy()
                res_data = predicted(GetSpecies, GetSequence_dict)
                return_data = []
                start_time = str(int(round((datetime.datetime.now()).timestamp() * 1000)))
                randlen = random.randint(0, len(start_time))
                start_time = start_time[randlen:] + start_time[0:randlen]
                f = open('./media/' + start_time + '.txt', 'wb+')
                write_str = 'Title' + '    ' + 'Sequences' + '    ' + 'Label' + '\n'
                f.write(write_str.encode())
                for title, seq in res_data.items():
                    if seq == 1.0:
                        result = 'PseU'
                    else:
                        result = 'Non-PseU'
                    return_data.append(({
                        'Title': title,
                        'Sequences': GetSequence_seq[title][0],
                        'Label': result,
                    }))
                    write_str = str(title) + '    ' + str(GetSequence_seq[title][0]) + '    ' + str(result) + '\n'
                    f.write(write_str.encode())
                f.close()

                return Response({
                    "send": 'Prediction success!!',
                    'Species': species,
                    "res_data": return_data,
                    "uuid": start_time,
                }, status=status.HTTP_201_CREATED, headers=headers)
            except:
                return Response({
                    "res_data": [],
                    "send": "Error, the sequences has characters except 'ACGU'.",
                }, status=status.HTTP_201_CREATED, headers=headers)

        else:
            return Response({
                "send": 'Prediction error!!'
            }, status=status.HTTP_400_BAD_REQUEST)


class UploadView(mixins.CreateModelMixin, viewsets.GenericViewSet):
    serializer_class = UploadSerializer

    def create(self, request, *args, **kwargs):
        GetSequence_dict = {}
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            GetFile = serializer.validated_data["UploadFile"]
            headers = self.get_success_headers(serializer.data)
            start_time = str(int(round((datetime.datetime.now()).timestamp() * 1000)))
            FilePath = "./media/" + start_time + GetFile.name
            destination = open(FilePath, 'wb+')
            for chunk in GetFile.chunks():
                destination.write(chunk)
            destination.close()
            return Response({
                    "send": 'send success!!',
                    'return_path': FilePath
                }, status=status.HTTP_201_CREATED, headers=headers)
        else:
            return Response({
                "send": 'get word failed!!'
            }, status=status.HTTP_400_BAD_REQUEST)


def DownloadFile(request, param):
    file_path = './media/' + param + '.txt'
    with open(file_path) as f:
        file_all = f.read()
    file_name = parse.quote(param+'.txt')
    response = FileResponse(file_all)
    response['Content-Type'] = 'text/plain'
    response['content-disposition'] = f'attachment;filename={file_name}'
    # if param not in ['H_200', 'S_200', 'H_990', 'S_628', 'M_944']:
    #     os.remove(file_path)
    return response


