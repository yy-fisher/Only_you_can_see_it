// miniprogram/pages/list/list.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    man:[],
    notiman:[],
    result:[],
    b:[],
    manlist:[],
    product:[],
    mes: null,
    pid: null,

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.onQuery()

  },

  onQuery: function(detail_id) {
    var that = this
    const db = wx.cloud.database()

     //总表
     db.collection('friendslist').where({
     
    }).get({
      success: res => {
        that.data.product = res.data

        //wx.lin.renderWaterFlow(that.data.product);
        console.log(res.data.length)
        // console.log(res.data[0])

        //总列表man
        var man = []
        for(let i=0; i<res.data.length; i++)
        {
          man.push(res.data[i])
        }
        this.data.man = man
        console.log(this.data.man)

        //关注表
        db.collection('list').where({
          _openid: this.data._openid
        }).get({
          success: res => {
            that.data.product = res.data
            
            //关注列表notiman
            var notiman = []
            for(let i=0; i<res.data.length; i++)
            {
              notiman.push(res.data[i])
            }
            that.data.notiman = notiman
            console.log(that.data.notiman)

            console.log('ownper[数据库] [查询记录] 成功: ', res)

            this.onResult()

          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '查询记录失败'
            })
            console.error('ownper[数据库] [查询记录] 失败：', err)
          }
        })


        //渲染 
        // that.setData({
        //   manlist:this.data.man
        // })
        console.log('man[数据库] [查询记录] 成功: ', res)
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })


  

  },

  onResult: function (params) {
    console.log("notiman", this.data.notiman)
    console.log("man",this.data.man)

    var result = []
    for(let i=0; i<this.data.man.length; i++)
    {
      var obj = this.data.man[i]
      var num = obj._id
      var flag = false
      // console.log("num",num)
      for(let j=0; j<this.data.notiman.length; j++)
      {
        var aj = this.data.notiman[j]
        var n = aj._id
        // console.log("n", n)
        if(n==num)
        {
          flag = true
          break
        }
      }
      if(!flag)
      {
        result.push(obj)
      }
    }
    this.data.result = result
    console.log("result",this.data.result)

    var that = this
    that.setData({
      manlist:that.data.result
    })
    
  },

  search: function (e) {
    this.data.val = e.detail.value
     const db = wx.cloud.database()
     //console.log(this.data.val)
     var that = this
     db.collection('friendslist').where({
       //使用正则查询，实现对搜索的模糊查询
         name: db.RegExp({
         regexp: this.data.val,
         //从搜索栏中获取的value作为规则进行匹配。
         options: 'i',
         //大小写不区分
       })
     }).get().then(res=>{
       //console.log(res.data,1)
       var a=[]
       this.data.product = res.data
       this.data.len_now = this.data.product.length
       this.setData({
         a: this.data.product
       }) 
       console.log(this.data.a,11)
       console.log(this.data.result,22)
       var b = []
    for(let i=0; i<this.data.result.length; i++)
    {
      var obj = this.data.result[i]
      var num = obj._id
      var flag = false
      // console.log("num",num)
      for(let j=0; j<this.data.a.length; j++)
      {
        var aj = this.data.a[j]
        var n = aj._id
        // console.log("n", n)
        if(n==num)
        {
          flag = true
          break
        }
      }
      if(flag)
      {
        b.push(obj)
      }
    }
    this.data.b = b
    console.log("b",this.data.b)

    var that = this
    that.setData({
      manlist:that.data.b
    })
    


     })
  },

  clean: function (e) {
    this.onQuery()
  },

  //添加
  onNoti: function (params) {
    // console.log("par",params)
    const db = wx.cloud.database()
    var that = this
    const item = params.currentTarget.dataset.item
    const pid = item._id

    console.log("item",item)

    db.collection("list").add({     
      data: {
        _id: item._id,
        name: item.name,
        img:item.img,
      },

      success: function(res) {
      wx.showToast({
              title: '添加成功',
            })
          that.onLoad()
      },
      fail:err => {
        wx.showToast({
          title: '您已添加该好友',
        })
        console.error('[数据库] [新增记录] 失败：', err)
      }
    })
    
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})