// pages/demo1/component/product/index.js
var minOffset = 50; //最小偏移量，低于这个值不响应滑动处理
var minTime = 60; // 最小时间，单位：毫秒，低于这个值不响应滑动处理
var startX = 0; //开始时的X坐标
var startY = 0; //开始时的Y坐标
var startTime = 0; //开始时的毫秒数
var index = 1
const app = getApp();
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    res: {
      type: Object,

    },
    collection: {
      type: Boolean,
      value: ''

    },
    Count: {
      type: Number,
      observer: function (newVal, oldVal) {
        console.log('properties-count', newVal)

      },

    },
    time: {
      type: String,
      watch: function (newVal, oldVal) {
        console.log('watch-time', newVal)
      }
    },
    month: String,
    year: String,
    sky: String,
    city: String,
    weather: String,
    temperature: Number
  },

  /**
   * 组件的初始数据
   */
  data: {
    collection: false,

  },
  /**
   * 组件的方法列表
   */

  ready: function () {
    // app.slideupshow(this, 'slide_up1', 10, 1)

  },
  methods: {
    dianzan: function (e) {
      var that = this
      console.log(that.properties.time, "trh")
      var collection = this.data.collection
      if (!collection) {
        collection = !collection
        const db = wx.cloud.database()
        console.log(that.data.time, "852")
        db.collection('images').where({
          date: that.data.time
        }).get().then((res) => {
          console.log(res, "jhk")
          var newCount = parseInt(res.data[0].count) + 1
          db.collection("images").doc(res.data[0]._id).update({
            data: {
              count: newCount
            },
            success: res => {
              console.log(res, "5857")
              that.setData({
                count: newCount,
                collection: collection,
              })
              console.log(newCount, "99-0")
              this.triggerEvent('dianzan', newCount)
            },
            fail: err => {
              icon: 'none',
              console.error('[数据库] [更新记录] 失败：', err)
            }
          })
        })

      } else {
        collection = !collection
        const db = wx.cloud.database()
        db.collection('images').where({
          date: that.data.time
        }).get().then((res) => {
          console.log(res, "jhk")
          var newCount = parseInt(res.data[0].count) - 1
          db.collection("images").doc(res.data[0]._id).update({
            data: {
              count: newCount
            },
            success: res => {
              console.log(res, "5857")
              that.setData({
                count: newCount,
                collection: collection,
              })
              this.triggerEvent('dianzan', newCount)
            },
            fail: err => {
              icon: 'none',
              console.error('[数据库] [更新记录] 失败：', err)
            }
          })
        })
      }




    },


    touchStart: function (e) {
      console.log('touchStart', e)
      startX = e.touches[0].pageX; // 获取触摸时的x坐标  
      startY = e.touches[0].pageY; // 获取触摸时的x坐标
      startTime = new Date().getTime(); //获取毫秒数
    },
    touchCancel: function (e) {
      startX = 0; //开始时的X坐标
      startY = 0; //开始时的Y坐标
      startTime = 0; //开始时的毫秒数
    },
    touchEnd: function (e) {
      // app.slideupshow(this, 'slide_up1', -10, 1)
      var endX = e.changedTouches[0].pageX;
      var endY = e.changedTouches[0].pageY;
      var touchTime = new Date().getTime() - startTime; //计算滑动时间
      //开始判断
      //1.判断时间是否符合
      if (touchTime >= minTime) {
        //2.判断偏移量：分X、Y
        var xOffset = endX - startX;
        var yOffset = endY - startY;
        console.log('xOffset', xOffset)
        console.log('yOffset', yOffset)
        //①条件1（偏移量x或者y要大于最小偏移量）
        //②条件2（可以判断出是左右滑动还是上下滑动）
        if (Math.abs(xOffset) >= Math.abs(yOffset) && Math.abs(xOffset) >= minOffset) {
          //左右滑动
          //③条件3（判断偏移量的正负）
          if (xOffset < 0) {

            var dateConvert1 = new Date(Date.parse(this.data.time)) - 86400000;
            index++;
            console.log('左滑')
            Date.prototype.toLocaleString = function () {
              if (this.getMonth() < 9) {
                return this.getFullYear() + "-0" + (this.getMonth() + 1) + "-" + this.getDate()
              } else {
                return this.getFullYear() + "-" + (this.getMonth() + 1) + "-" + this.getDate()
              }
            };
            var unixTimestamp = new Date(dateConvert1);
            var commonTime = unixTimestamp.toLocaleString();
            console.log(commonTime, "244");
            this.setData({
              time: commonTime,

            })
            console.log(this.data.time, "741")
            const db = wx.cloud.database()
            db.collection("images").where({
              date: this.data.time
            }).get({
              success: res => {
                res.data[0].index = index
                console.log(res, "89")
                this.setData({
                  images: res.data[0].images,
                  gra: res.data[0].gra,
                  dec: res.data[0].dec,
                  aut: res.data[0].aut,
                  count: res.data[0].count,
                  image: res.data
                })
                this.triggerEvent("touchEnd", res)

                console.log('[数据库] [查询记录] 成功: ', res)
              },
              fail: err => {
                wx.showToast({
                  icon: 'none',
                  title: '暂无数据可查询'
                })
                console.error('[数据库] [查询记录] 失败：', err)
              }

            })

          } else {
            //youco
            index--;
            console.log("右滑")
            var dateConvert1 = new Date(Date.parse(this.data.time)) - (-86400000);
            // console.log(index,"张数")
            Date.prototype.toLocaleString = function () {
              if (this.getMonth() < 9) {
                if (this.getDate() < 9) {
                  return this.getFullYear() + "-0" + (this.getMonth() + 1) + "-0" + this.getDate()
                } else {
                  return this.getFullYear() + "-0" + (this.getMonth() + 1) + "-" + this.getDate()
                }
              } else if (this.getDate() < 9) {
                return this.getFullYear() + "-" + (this.getMonth() + 1) + "-0" + this.getDate()
              } else {
                return this.getFullYear() + "-" + (this.getMonth() + 1) + "-" + this.getDate()
              }
            };
            var unixTimestamp = new Date(dateConvert1);
            var commonTime = unixTimestamp.toLocaleString();
            console.log(commonTime, "244");
            this.setData({
              time: commonTime,

            })
            console.log(this.data.time, "741")
            const db = wx.cloud.database()
            db.collection("images").where({
              date: this.data.time
            }).get({
              success: res => {
                res.data[0].index = index
                console.log(res, "89")
                this.setData({
                  images: res.data[0].images,
                  gra: res.data[0].gra,
                  dec: res.data[0].dec,
                  aut: res.data[0].aut,
                  count: res.data[0].count,
                  image: res.data
                })
                res.data[0].index = index
                this.triggerEvent("touchEnd", res)

                console.log('[数据库] [查询记录] 成功: ', res)
              },
              fail: err => {
                wx.showToast({
                  icon: 'none',
                  title: '暂无数据可查询'
                })
                console.error('[数据库] [查询记录] 失败：', err)
              }

            })

          }
        } else if (Math.abs(xOffset) < Math.abs(yOffset) && Math.abs(yOffset) >= minOffset) {
          //上下滑动
          //③条件3（判断偏移量的正负）
          if (yOffset < 0) {
            console.log('向上滑动')
          } else {
            console.log('向下滑动')
          }
        }
      } else {
        console.log('滑动时间过短', touchTime)
      }


    },




  }
})