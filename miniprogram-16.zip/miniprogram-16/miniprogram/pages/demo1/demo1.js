var amapFile = require('../map/amap-wx.js'); //如：..­/..­/libs/amap-wx.js
var utils = require('../utils/utils.js');
var that = this
const db = wx.cloud.database()
const app = getApp();
Page({
  data: {
    collection: false,
    commonTime: "",
    time: '',
    image: [],
    _openid: '',
    images: '',
    data: {},
    city: '',
    weather: '',
    temperature: '',
    time1: '',

  },
  onLoad: function () {
    this.data._openid = app.globalData._openid
    wx.setBackgroundColor({
      backgroundColorTop: '#ffffff', // 顶部窗口的背景色为白色
    })
    this.Query()



  },

  Query: function () {
    var date = utils.formatTime(new Date())
    var date1 = new Date(); //可以在date中指定日期转换
    var month = date1.toDateString().split(" ")[1];
    var time1 = date.split(' ') //如果只需要年月日，不需要时分秒就写此语句
    console.log(time1[0]) //年月日
    var time = time1[0].split("-")
    var data1 = time[2]
    var year = time[0]
    this.setData({
      month: month,
      data: data1,
      year: year,
      time: time1[0],
      count: 0,
      time1: time1[0]
    })
    this.setData({
      collection: this.data.collection
    })

    //天气函数
    var that = this;
    var myAmapFun = new amapFile.AMapWX({
      key: 'b70f58506549c79ceea5c9ff0f6b0c3c'
    });
    myAmapFun.getWeather({
      success: function (data) {
        that.setData({
          city: data.city.data,
          weather: data.liveData.weather,
          temperature: data.liveData.temperature,

        })

        console.log(that.data.temperature)
      },
      fail: function (info) {
        //失败回调
        console.log(info)
      }
    })
    //数据库函数
    console.log(that.data.city)

    db.collection('images').where({
      _openid: this.data._openid
    }).get({
      success: res => {

        that.setData({
          image: res.data,
        })

        for (let index = 0; index < that.data.image.length; index++) {
          var date4 = res.data[index].date
          date4 = new Date(date4)
          var month1 = date4.toDateString().split(" ")[1]
          var time3 = that.data.image[index].date.split("-")
          that.data.image[index].collection = that.data.collection
          that.data.image[index].city = that.data.city
          that.data.image[index].weather = that.data.weather
          that.data.image[index].temperature = that.data.temperature
          that.data.image[index].month = month1
          that.data.image[index].year = time3[0]
          that.data.image[index].data = time3[2]
        }

        console.log(that.data.image, "yt")

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
    db.collection("images").where({
      date: time1[0]
    }).get().then((res) => {
      that.setData({
        images: res.data[0].images,
        gra: res.data[0].gra,
        dec: res.data[0].dec,
        aut: res.data[0].aut,
        count: res.data[0].count,
        month: res.data[0].month
      })
    })
    that.setData({
      image: that.data.image,
    })
  },
  onShareAppMessage: function (res) {
    var that = this;
    return {
      title: '',
      path: "pages/demo1/demo1",
      success: function (res) {
        // 转发成功
        console.log("123")

        wx.showToast({
          title: '转发成功',
          icon: 'success',
          duration: 2000
        })

      },
      fail: function (res) {
        // 转发失败
        wx.showToast({
          title: '转发失败',
          icon: 'fail',
          duration: 2000
        })
      }

    }
  },
  Dianzan(e) {
    var that = this
    console.log(e.detail, "000")
    console.log(e.detail, "yhy")
    db.collection("images").where({
      date: this.data.time1
    }).get().then((res) => {
      console.log(res.data[0], "33")
      this.setData({
        count: res.data[0].count,
        image: that.data.image,
      })
    })

  },


  TouchEnd(e) {
    console.log(e.detail.data[0], "142")
    var that = this
    db.collection("images").where({
      date: e.detail.data[0].date
    }).get().then((res) => {
      console.log(res, "8575")
      this.data.date1 = res.data[0].date
      this.data.date1 = new Date(this.data.date1)
      var month1 = this.data.date1.toDateString().split(" ")[1]
      res.data[0]['month'] = month1
      console.log(res.data, "fe")
      that.setData({
        date1: res.data[0].date,
        time1: res.data[0].date,
        count: res.data[0].count,
        image: res.data.image,
        year: res.data[0].date.split("-")[0],
        month: res.data[0].month,
        data: res.data[0].date.split("-")[2]
      })
      // this.Query()
      console.log(this.data.month)


    })
    // var len =this.data.image.length
    // if (e.detail.data[0].index>len||e.detail.data[0].index<1){
    //   wx.showToast({
    //     title: '暂无数据',
    //     icon: 'fail',
    //     duration: 2000
    //   })
    // }
    console.log(this.data.image, "85")
  }

})