// miniprogram/pages/demo3.py/demo3.js
var amapFile = require('../map/amap-wx.js'); //如：..­/..­/libs/amap-wx.js
var utils = require('../utils/utils.js');
var that = this
const db = wx.cloud.database()
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    xiaoshi: true,
    shangchuan: false,
    tempFilePaths: "",
    commonTime: "",
    time: '',
    image: [],
    _openid: '',
    images: '',
    data: {},
    city: '',
    weather: '',
    temperature: '',
    time1: '',
    encryptionimage: '',
    text: '',
    publickey: '',
    privatekey: '',
    GetFilePath: '',
    imgPath: '',
    GetText: '',
    shoudao: false,
    receive: false
  },
  trigger() {
    let vm = this;
    if (!this.data.text) {
      wx.showToast({
        icon: 'error',
        title: '请先输入文本'
      })
    } else if (!this.data.shangchuan) {
      wx.showToast({
        icon: 'error',
        title: '请先上传图片'
      })
    } else if (!this.data.receive) {
      wx.showToast({
        icon: 'error',
        title: '请等待图片上传'
      })
    }
      else {
      let option = {
        duration: 5000, // 动画执行时间
        timingFunction: 'ease-in' // 动画执行效果
      };
      var lanimation = wx.createAnimation(option); // 创建动画
      var ranimation = wx.createAnimation(option);
      var zanimation = wx.createAnimation(option);
      // 起点  zAnimate
      lanimation.translateY(60);
      lanimation.opacity(1).step();
      zanimation.translateY(60);
      zanimation.opacity(0).step();
      // 终点
      ranimation.translateY(-160);
      ranimation.opacity(0).step();
      vm.setData({
        lAnimate: lanimation.export(), // 开始执行动画
        rAnimate: ranimation.export(), // 开始执行动画
        zAnimate: zanimation.export(),
        shangchuanl: true,
        xiaoshi: false
      })
    }
    const db = wx.cloud.database()
    db.collection('user_id').where({
      _openid: app.globalData.openid
    }).get().then(res => {
      vm.data.privatekey = res.data[0].private_key
      console.log(vm.data.privatekey, "q")
      vm.data.publickey = res.data[0].public_key
      wx.request({
        url: 'https://xcx.kareza.cn/encode/',
        method: 'POST',
        data: {
          UploadFilePath: this.data.encryptionimage,
          Key: vm.data.publickey,
          Text: this.data.text
        },
        header: {
          'content-type': "application/json"
        },
        success: function (res) {
          console.log(res.data) //返回的会是对象，可以用JSON转字符串打印出来方便查看数据
          if (!res.data.imgPath) {
            this.data.encryptionimage = "您上传的信息有误，请确认后重新上传"
          }
          var image1 = res.data.imgPath
          image1 = image1.replace('.', '')
          console.log(image1, 'HFu')
          if (!image1) {
            wx.showLoading({
              title: '请耐心等待',
            })
          } else {
            vm.data.encryptionimage = "https://xcx.kareza.cn" + image1
            vm.setData({
              image: vm.data.encryptionimage,
              timeval: true,
              shoudao: true
            })
            console.log(vm.data.encryptionimage, "fehsufh")
          }

        },
        fail: function (fail) {
          // 这里是失败的回调，取值方法同上,把res改一下就行了  
        },
        complete: function (arr) {
          console.log(arr.data.imgPath, "ew")
          vm.data.GetFilePath = arr.data.GetFilePath
          vm.data.imgPath = arr.data.imgPath
          vm.data.GetText = arr.data.GetText
        }
      })
    })

  },

  confirmtext: function (e) {
    console.log(e.detail.value, "fhdh")
    this.data.text = e.detail.value
  },
  saveImg(e) {
    var imgSrc = this.data.image
    wx.downloadFile({
      url: imgSrc,
      success: function (res) {
        console.log(res, "图片保存");
        //图片保存到本地
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: function (data) {
            console.log(data);
          },
          fail: function (err) {
            console.log(err);
            if (err.errMsg === "saveImageToPhotosAlbum:fail auth deny") {
              console.log(
                "用户一开始拒绝了，我们想再次发起授权")
              console.log('打开设置窗口')
              wx.openSetting({
                success(settingdata) {
                  console.log(settingdata)
                  if (settingdata.authSetting['scope.writePhotosAlbum']) {
                    console.log('获取权限成功，给出再次点击图片保存到相册的提示')
                  } else {
                    console.log(
                      '获取权限失败，给出不给权限就无法正常使用的提示'
                    )
                  }
                }
              })
            }

          }

        })

      }

    })


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(this.data.shangchuan)
    this.Query();
  },
  Query: function () {
    var date = utils.formatTime(new Date())
    var date1 = new Date(); //可以在date中指定日期转换
    var month = date1.toDateString().split(" ")[1];
    var time1 = date.split(' ') //如果只需要年月日，不需要时分秒就写此语句
    console.log(time1[0]) //年月日
    var time = time1[0].split("-")
    var data1 = time[2]
    var year = time[0]
    this.setData({
      month: month,
      data: data1,
      year: year,
      time: time1[0],
      count: 0,
      time1: time1[0]
    })
    //天气函数
    var that = this;

    var myAmapFun = new amapFile.AMapWX({
      key: 'b70f58506549c79ceea5c9ff0f6b0c3c'
    });
    myAmapFun.getWeather({
      success: function (data) {
        that.setData({
          city: data.city.data,
          weather: data.liveData.weather,
          temperature: data.liveData.temperature,

        })

        console.log(that.data.temperature)
      },
      fail: function (info) {
        //失败回调
        console.log(info)
      }
    })
    //数据库函数
    console.log(that.data.city)

    db.collection('images').where({
      _openid: this.data._openid
    }).get({
      success: res => {

        that.setData({
          image: res.data,
        })

        for (let index = 0; index < that.data.image.length; index++) {
          var date4 = res.data[index].date
          date4 = new Date(date4)
          var month1 = date4.toDateString().split(" ")[1]
          var time3 = that.data.image[index].date.split("-")
          that.data.image[index].collection = that.data.collection
          that.data.image[index].city = that.data.city
          that.data.image[index].weather = that.data.weather
          that.data.image[index].temperature = that.data.temperature
          that.data.image[index].month = month1
          that.data.image[index].year = time3[0]
          that.data.image[index].data = time3[2]
        }

        console.log(that.data.image, "yt")

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
    console.log(that.data.image, "ybgft")
    db.collection("images").where({
      date: time1[0]
    }).get().then((res) => {
      console.log(res.data, "gf")
      that.setData({
        images: res.data[0].images,
        gra: res.data[0].gra,
        dec: res.data[0].dec,
        aut: res.data[0].aut,
        count: res.data[0].count,
        month: res.data[0].month
      })
    })
    that.setData({
      image: that.data.image,
    })
    console.log(this.data.image, "gh")
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  upimage: function () {

    var that = this
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: 'compressed', // 可以指定是原图还是压缩图，默认二者都有
      // sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        that.data.tempFilePaths = res.tempFilePaths;
        // var tempFile = res.tempFiles
        console.log(that.data.tempFilePaths)
        if (that.data.tempFilePaths) {
          that.data.shangchuan = true
          that.setData({
            shangchuan: true,
            image: that.data.tempFilePaths
          })
        }
        wx.uploadFile({
          url: "https://xcx.kareza.cn/upload/",
          filePath: that.data.tempFilePaths[0], //通过选择按钮获取的图片地址
          name: 'UploadFile', // key
          header: {
            'content-type': "application/json"
          },
          success: function (res) {
            console.log(res.data, "cdc")
            that.setData({
              receive: true
            })
            wx.showToast({
              title: '上传成功',
              icon:'success'
            })
            that.data.encryptionimage = res.data.split(":")[2].replace('}', '').replace('"', "").replace('"', '')

          },
          fail(res) {
            console.log(res, "2")
          },
          complete(res) {
            console.log(res, "dfdsyufgyu")
          }

        })

      }

    })




  },
  close: function () {
    this.setData({
      shangchuan: false
    })

  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log("执行删除图片操作")
    wx.request({
      url: 'https://xcx.kareza.cn/delete/',
      method: 'POST',
      data: {
        Deleteimage: this.data.GetFilePath,
        Deletetext: this.data.GetText,
        Deleteendimage: this.data.imgPath
      },
      header: {
        'content-type': "application/json"
      },
      success: function (res) {
        console.log(res.data) //返回的会是对象，可以用JSON转字符串打印出来方便查看数据

      },
      fail: function (fail) {
        // 这里是失败的回调，取值方法同上,把res改一下就行了  
      },
      complete: function (arr) {
        // 这里是请求以后返回的所以信息，请求方法同上，把res改一下就行了  
      }
    })


  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {



  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})