// miniprogram/pages/demo3.py/demo3.js
var amapFile = require('../map/amap-wx.js');//如：..­/..­/libs/amap-wx.js
var utils = require('../utils/utils.js');
var that = this
const db = wx.cloud.database()
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    xiaoshi:true,
    loading:false,
    shangchuan:false,
    shangchuanl:false,
    tempFilePaths:"",
    commonTime:"",
    time:'',
    image:[],
    _openid:'',
    images:'',
    data:{},
    city:'',
    weather:'',
    temperature:'',
    time1:'',
  },
  trigger() {
    let vm = this;
    if (!this.data.shangchuan) {
      wx.showToast({
        icon: 'error',
        title: '请先上传图片'
      })
    }else{
   
    vm.setData({
      loading:true
    })
    var option = {
      duration: 200, // 动画执行时间
      timingFunction: 'ease-in' ,// 动画执行效果,
     
    };
    var lanimation = wx.createAnimation(option); // 创建动画
    var ranimation = wx.createAnimation(option);
    var zanimation = wx.createAnimation(option);
    // 起点
    lanimation.translateY(-15);
    lanimation.opacity(1).step();
    zanimation.translateY(-65);
    zanimation.opacity(1).step();
    // 终点
    ranimation.translateY(230);
    ranimation.opacity(1).step();
    vm.setData({
      lAnimate: lanimation.export(),// 开始执行动画
      rAnimate: ranimation.export(), // 开始执行动画
      zAnimate: zanimation.export(),
      shangchuanl:true,
      xiaoshi:false
    })
    setTimeout(() => {
      // 起点
      lanimation.translateX(0);
      lanimation.opacity(1).step();
      // 终点
      ranimation.translateX(0);
      ranimation.opacity(1).step();
      var temp = vm.data.start;
      vm.setData({
        lAnimate: lanimation.export(),// 开始执行动画
        rAnimate: ranimation.export(),// 开始执行动画
        end: temp,
        start: vm.data.end
      })
    }, 5000);
    }
    setInterval(function () {
      vm.setData({
       loading: false
      })
    },5000)
    console.log(this.data.loading,"fa")
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(this.data.shangchuan)
    this.Query();
  },
  Query:function () {
    var date = utils.formatTime(new Date())
    var date1 = new Date(); //可以在date中指定日期转换
    var month = date1.toDateString().split(" ")[1];
    var time1 = date.split(' ') //如果只需要年月日，不需要时分秒就写此语句
    console.log(time1[0]) //年月日
    var time = time1[0].split("-")
    var data1 = time[2]
    var year = time[0]
    this.setData({
      month: month,
      data: data1,
      year: year,
      time:time1[0],
      count:0,
      time1:time1[0]
    })
    //天气函数
    var that = this;
    var myAmapFun = new amapFile.AMapWX({key:'b70f58506549c79ceea5c9ff0f6b0c3c'});
    myAmapFun.getWeather({
      success: function(data){
        that.setData({
          city:data.city.data,
          weather:data.liveData.weather,
          temperature:data.liveData.temperature,
          
        })
       
        console.log(that.data.temperature)
      },
      fail: function(info){
        //失败回调
        console.log(info)
      }
    })
  //数据库函数
  console.log(that.data.city)
  
    db.collection('images').where({
     _openid:this.data._openid
    }).get({
      success: res => {
        
       that.setData({
         image:res.data,
       })
       
     for (let index = 0; index < that.data.image.length; index++) {
        var date4  = res.data[index].date
        date4 = new Date(date4)
        var month1 = date4.toDateString().split(" ")[1]
        var time3= that.data.image[index].date.split("-")
        that.data.image[index].collection = that.data.collection
        that.data.image[index].city = that.data.city
        that.data.image[index].weather = that.data.weather
        that.data.image[index].temperature = that.data.temperature
        that.data.image[index].month = month1
        that.data.image[index].year =  time3[0]
        that.data.image[index].data =  time3[2]
     }
  
       console.log(that.data.image,"yt")
      
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '查询记录失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })
    console.log(that.data.image,"ybgft")
    db.collection("images").where({
      date: time1[0]
    }).get().then((res) => {
      console.log(res.data,"gf")
      that.setData({
        images: res.data[0].images,
        gra:res.data[0].gra,
        dec:res.data[0].dec,
        aut:res.data[0].aut,
        count:res.data[0].count,
        month:res.data[0].month
      })
    })
    that.setData({
      image: that.data.image,
    })
    console.log(this.data.image,"gh")
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },
  upimage:function () {
    var that = this
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: 'original', // 可以指定是原图还是压缩图，默认二者都有
      // sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
      // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
      that.data.tempFilePaths = res.tempFilePaths;
      // var tempFile = res.tempFiles
      console.log(that.data.tempFilePaths)
      if (that.data.tempFilePaths) {
        that.data.shangchuan = true
        that.setData({
          shangchuan:true,
          image:that.data.tempFilePaths
        })
       
      }
      // console.log(tempFiles)
      // wx.uploadFile({
      // // url: 'https://...', //此处换上你的接口地址
      // filePath: tempFilePaths[0],
      // name: 'img',
      // header: { 
      // "Content-Type": "multipart/form-data",
      // 'accept': 'application/json',
      // 'Authorization': 'Bearer ..' //若有token，此处换上你的token，没有的话省略
      // },
      // formData:{
      // 'user':'test' //其他额外的formdata，可不写
      // },
      // success: function(res){
      // var data=res.data;
      // console.log('data');
      // },
      // fail: function(res){
      // console.log('fail');
       
      // },
      // })
      }
      
      })
      


  
}, 

saveImg(e){
  console.log(e,'fd')
  let image = e.currentTarget.dataset.image[0];
  //用户需要授权
  wx.getSetting({
   success: (res) => {
    if (!res.authSetting['scope.writePhotosAlbum']) {
     wx.authorize({
      scope: 'scope.writePhotosAlbum',
      success:()=> {
       // 同意授权
       this.saveImg1(image);
      },
      fail: (res) =>{
       console.log(res);
      }
     })
    }else{
     // 已经授权了
     this.saveImg1(image);
    }
   },
   fail: (res) =>{
    console.log(res);
   }
  })  
 },
 saveImg1(image){
  wx.getImageInfo({
   src: image,
   success:(res)=> {
    let path = res.path;
    wx.saveImageToPhotosAlbum({
     filePath:path,
     success:(res)=> { 
      console.log(res);
     },
     fail:(res)=>{
      console.log(res);
     }
    })
   },
   fail:(res)=> {
    console.log(res);
   }
  })
 },

close:function(){
this.setData({
  shangchuan:false
})

},
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})