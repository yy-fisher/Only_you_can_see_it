// miniprogram/pages/demo2/demo2.js
const app = getApp()
Page({

  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
    userid: '',
    publickey: '',
    privatekey: ''
  },
  onLoad() {
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      })
    }
  },
  getUserProfile(e) {
    var that = this
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log("用户id为：", app.globalData.openid)
        this.data.userid = this.uuid(8, 2)
        console.log(this.data.userid, "fbsd")
        const db = wx.cloud.database()
        db.collection('user_id').where({
          _openid: app.globalData.openid
        }).get().then(res => {
          console.log(res.data, 'r')
          if (res.data.length == 0) {
            wx.request({
              url: 'http://127.0.0.1:8000/key/',
              method: 'POST',
              data: {
                Key: app.globalData.openid,
              },
              header: {
                'content-type': "application/json"
              },
              success: function (res) {
                console.log(res.data.privatekey)
                console.log(that.data.userid, "uuid")
                that.data.privatekey = res.data.privatekey
                that.data.publickey = res.data.publickey
                const db = wx.cloud.database()
                db.collection('user_id').add({
                  data: {
                    uuid: that.data.userid,
                    private_key: that.data.privatekey,
                    public_key: that.data.publickey
                  },
                  success: res2 => {
                    console.log(res2, "qwe")
              
                  },
                  fail: err => {
                    console.error('[数据库] [新增记录] 失败：', err)
                  }
                })

                //返回的会是对象，可以用JSON转字符串打印出来方便查看数据
              },
              fail: function (fail) {
                // 这里是失败的回调，取值方法同上,把res改一下就行了  
              },
              complete: function (arr) {
                // 这里是请求以后返回的所以信息，请求方法同上，把res改一下就行了  
              }
            })
            console.log(that.data.privatekey, "dddd")

          } else {
            console.log("用户已经授权了")
          }
        }).catch(err => {
          console.log(err) //打印错误信息
        })

        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
        wx.showToast({
          icon: 'success',
          title: '授权成功'
        })
        console.log(res)
      },
      fail: (res) => {
        wx.showToast({
          icon: 'error',
          title: '授权失败'
        })
        console.error('[数据库] [查询记录] 失败：', res)

      }
    })

  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  uuid: function (len, radix) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
    var uuid = [],
      i;
    radix = radix || chars.length;

    if (len) {
      // Compact form
      for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
    } else {
      // rfc4122, version 4 form
      var r;

      // rfc4122 requires these characters
      uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
      uuid[14] = '4';

      // Fill in random data. At i==19 set the high bits of clock sequence as
      // per rfc4122, sec. 4.1.5
      for (i = 0; i < 36; i++) {
        if (!uuid[i]) {
          r = 0 | Math.random() * 16;
          uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
        }
      }
    }

    return uuid.join('');
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})